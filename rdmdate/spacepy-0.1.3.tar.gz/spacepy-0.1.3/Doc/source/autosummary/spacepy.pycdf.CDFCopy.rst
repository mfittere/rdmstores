spacepy.pycdf.CDFCopy
=====================

.. currentmodule:: spacepy.pycdf

.. autoclass:: CDFCopy