spacepy.pycdf.CDFWarning
========================

.. currentmodule:: spacepy.pycdf

.. autoclass:: CDFWarning