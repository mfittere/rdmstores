spacepy.time.sec2hms
====================

.. currentmodule:: spacepy.time

.. autofunction:: sec2hms