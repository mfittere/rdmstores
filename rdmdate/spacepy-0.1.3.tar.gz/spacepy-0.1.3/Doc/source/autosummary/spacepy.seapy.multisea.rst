spacepy.seapy.multisea
======================

.. currentmodule:: spacepy.seapy

.. autofunction:: multisea