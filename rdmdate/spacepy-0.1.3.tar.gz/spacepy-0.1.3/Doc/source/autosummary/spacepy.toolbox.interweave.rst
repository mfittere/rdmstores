spacepy.toolbox.interweave
==========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: interweave