spacepy.pycdf.zAttrList
=======================

.. currentmodule:: spacepy.pycdf

.. autoclass:: zAttrList