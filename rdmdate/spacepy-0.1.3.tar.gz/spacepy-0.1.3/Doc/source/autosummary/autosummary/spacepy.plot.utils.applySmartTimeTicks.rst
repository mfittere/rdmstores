spacepy.plot.utils.applySmartTimeTicks
======================================

.. currentmodule:: spacepy.plot.utils

.. autofunction:: applySmartTimeTicks