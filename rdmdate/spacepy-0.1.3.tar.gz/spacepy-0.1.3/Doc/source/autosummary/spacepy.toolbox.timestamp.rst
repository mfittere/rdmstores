spacepy.toolbox.timestamp
=========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: timestamp