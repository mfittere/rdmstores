spacepy.toolbox.update
======================

.. currentmodule:: spacepy.toolbox

.. autofunction:: update