spacepy.data_assimilation.assimilate_JK
=======================================

.. currentmodule:: spacepy.data_assimilation

.. autofunction:: assimilate_JK