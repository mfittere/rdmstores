

############################################################################
lanlstar - module to calculate Lstar or Lmax using artificial neural network
############################################################################

.. currentmodule:: spacepy.LANLstar
.. automodule:: spacepy.LANLstar

