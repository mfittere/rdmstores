spacepy.datamodel.fromCDF
=========================

.. currentmodule:: spacepy.datamodel

.. autofunction:: fromCDF