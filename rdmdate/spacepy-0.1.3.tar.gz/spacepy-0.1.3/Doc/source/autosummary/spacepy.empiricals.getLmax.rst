spacepy.empiricals.getLmax
==========================

.. currentmodule:: spacepy.empiricals

.. autofunction:: getLmax