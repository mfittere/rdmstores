spacepy.plot.utils.smartTimeTicks
=================================

.. currentmodule:: spacepy.plot.utils

.. autofunction:: smartTimeTicks