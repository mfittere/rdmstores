spacepy.toolbox.randomDate
==========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: randomDate