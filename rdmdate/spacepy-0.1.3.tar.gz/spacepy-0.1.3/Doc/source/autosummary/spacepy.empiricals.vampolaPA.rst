spacepy.empiricals.vampolaPA
============================

.. currentmodule:: spacepy.empiricals

.. autofunction:: vampolaPA