spacepy.datamodel.fromHDF5
==========================

.. currentmodule:: spacepy.datamodel

.. autofunction:: fromHDF5