spacepy.seapy.seadict
=====================

.. currentmodule:: spacepy.seapy

.. autofunction:: seadict