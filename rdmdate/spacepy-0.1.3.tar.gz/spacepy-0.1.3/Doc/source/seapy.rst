

##################################
SeaPy - Superposed Epoch in Python
##################################

.. currentmodule:: spacepy.seapy

.. automodule:: spacepy.seapy

.. rubric:: Classes

.. autosummary::
    :template: clean_class.rst
    :toctree: autosummary

    Sea
    Sea2d

.. rubric:: Functions

.. autosummary::
    :toctree: autosummary

    seadict
    multisea
    readepochs
    sea_signif
