spacepy.time.Tickdelta
======================

.. currentmodule:: spacepy.time

.. autoclass:: Tickdelta