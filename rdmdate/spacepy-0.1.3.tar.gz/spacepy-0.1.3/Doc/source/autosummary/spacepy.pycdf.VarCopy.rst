spacepy.pycdf.VarCopy
=====================

.. currentmodule:: spacepy.pycdf

.. autoclass:: VarCopy