spacepy.datamodel.toHDF5
========================

.. currentmodule:: spacepy.datamodel

.. autofunction:: toHDF5