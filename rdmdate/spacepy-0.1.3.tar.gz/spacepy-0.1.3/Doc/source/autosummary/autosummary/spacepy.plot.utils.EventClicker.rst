spacepy.plot.utils.EventClicker
===============================

.. currentmodule:: spacepy.plot.utils

.. autoclass:: EventClicker