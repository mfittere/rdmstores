spacepy.toolbox.eventTimer
==========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: eventTimer