spacepy.LANLstar.LANLmax
========================

.. currentmodule:: spacepy.LANLstar

.. autofunction:: LANLmax