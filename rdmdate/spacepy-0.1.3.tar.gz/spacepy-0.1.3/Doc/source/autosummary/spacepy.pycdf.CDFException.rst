spacepy.pycdf.CDFException
==========================

.. currentmodule:: spacepy.pycdf

.. autoclass:: CDFException