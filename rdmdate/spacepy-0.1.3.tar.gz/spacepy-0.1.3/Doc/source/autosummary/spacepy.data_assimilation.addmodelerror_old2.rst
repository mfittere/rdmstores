spacepy.data_assimilation.addmodelerror_old2
============================================

.. currentmodule:: spacepy.data_assimilation

.. autofunction:: addmodelerror_old2