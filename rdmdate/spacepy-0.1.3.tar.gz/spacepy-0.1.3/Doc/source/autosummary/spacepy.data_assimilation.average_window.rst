spacepy.data_assimilation.average_window
========================================

.. currentmodule:: spacepy.data_assimilation

.. autofunction:: average_window