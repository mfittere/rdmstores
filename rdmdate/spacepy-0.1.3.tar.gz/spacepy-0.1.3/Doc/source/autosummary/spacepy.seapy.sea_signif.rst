spacepy.seapy.sea_signif
========================

.. currentmodule:: spacepy.seapy

.. autofunction:: sea_signif