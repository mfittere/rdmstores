spacepy.toolbox.human_sort
==========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: human_sort