spacepy.toolbox.listUniq
========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: listUniq