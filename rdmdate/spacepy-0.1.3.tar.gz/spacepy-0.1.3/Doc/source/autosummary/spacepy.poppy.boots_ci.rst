spacepy.poppy.boots_ci
======================

.. currentmodule:: spacepy.poppy

.. autofunction:: boots_ci