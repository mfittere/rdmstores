spacepy.toolbox.interpol
========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: interpol