spacepy.toolbox.linspace
========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: linspace