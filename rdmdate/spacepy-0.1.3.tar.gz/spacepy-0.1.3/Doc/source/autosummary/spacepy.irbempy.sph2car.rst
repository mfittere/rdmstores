spacepy.irbempy.sph2car
=======================

.. currentmodule:: spacepy.irbempy

.. autofunction:: sph2car