spacepy.toolbox.printfig
========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: printfig