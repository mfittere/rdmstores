spacepy.toolbox.pmm
===================

.. currentmodule:: spacepy.toolbox

.. autofunction:: pmm