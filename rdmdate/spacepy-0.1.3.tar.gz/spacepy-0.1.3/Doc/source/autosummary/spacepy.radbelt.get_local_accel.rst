spacepy.radbelt.get_local_accel
===============================

.. currentmodule:: spacepy.radbelt

.. autofunction:: get_local_accel