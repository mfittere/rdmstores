spacepy.irbempy.get_dtype
=========================

.. currentmodule:: spacepy.irbempy

.. autofunction:: get_dtype