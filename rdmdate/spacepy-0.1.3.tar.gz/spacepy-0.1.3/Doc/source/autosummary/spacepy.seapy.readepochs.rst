spacepy.seapy.readepochs
========================

.. currentmodule:: spacepy.seapy

.. autofunction:: readepochs