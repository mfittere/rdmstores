spacepy.irbempy.coord_trans
===========================

.. currentmodule:: spacepy.irbempy

.. autofunction:: coord_trans