spacepy.irbempy.get_AEP8
========================

.. currentmodule:: spacepy.irbempy

.. autofunction:: get_AEP8