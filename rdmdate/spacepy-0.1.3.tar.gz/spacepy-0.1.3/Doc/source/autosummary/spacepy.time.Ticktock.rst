spacepy.time.Ticktock
=====================

.. currentmodule:: spacepy.time

.. autoclass:: Ticktock