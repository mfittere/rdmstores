spacepy.toolbox.dist_to_list
============================

.. currentmodule:: spacepy.toolbox

.. autofunction:: dist_to_list