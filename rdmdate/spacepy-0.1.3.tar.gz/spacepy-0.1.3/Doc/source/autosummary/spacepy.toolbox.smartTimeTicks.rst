spacepy.toolbox.smartTimeTicks
==============================

.. currentmodule:: spacepy.toolbox

.. autofunction:: smartTimeTicks