spacepy.toolbox.windowMean
==========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: windowMean