spacepy.irbempy.get_Lstar
=========================

.. currentmodule:: spacepy.irbempy

.. autofunction:: get_Lstar