spacepy.time.doy2date
=====================

.. currentmodule:: spacepy.time

.. autofunction:: doy2date