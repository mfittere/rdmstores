spacepy.pycdf.zAttr
===================

.. currentmodule:: spacepy.pycdf

.. autoclass:: zAttr