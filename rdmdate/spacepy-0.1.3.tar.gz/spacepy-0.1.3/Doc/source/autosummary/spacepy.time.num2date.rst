spacepy.time.num2date
=====================

.. currentmodule:: spacepy.time

.. autofunction:: num2date