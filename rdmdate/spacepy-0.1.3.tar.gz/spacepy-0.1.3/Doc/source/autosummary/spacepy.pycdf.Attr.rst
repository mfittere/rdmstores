spacepy.pycdf.Attr
==================

.. currentmodule:: spacepy.pycdf

.. autoclass:: Attr