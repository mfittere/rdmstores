spacepy.toolbox.normalize
=========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: normalize