spacepy.pycdf.gAttr
===================

.. currentmodule:: spacepy.pycdf

.. autoclass:: gAttr