spacepy.toolbox.assemble
========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: assemble