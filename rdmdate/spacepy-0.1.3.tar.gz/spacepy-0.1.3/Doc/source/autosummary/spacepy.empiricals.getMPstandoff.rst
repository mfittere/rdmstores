spacepy.empiricals.getMPstandoff
================================

.. currentmodule:: spacepy.empiricals

.. autofunction:: getMPstandoff