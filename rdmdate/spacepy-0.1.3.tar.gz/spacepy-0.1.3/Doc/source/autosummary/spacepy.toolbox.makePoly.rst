spacepy.toolbox.makePoly
========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: makePoly