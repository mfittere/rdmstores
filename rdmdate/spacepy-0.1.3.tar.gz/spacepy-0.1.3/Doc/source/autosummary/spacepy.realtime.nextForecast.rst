spacepy.realtime.nextForecast
=============================

.. currentmodule:: spacepy.realtime

.. autofunction:: nextForecast