spacepy.irbempy.prep_irbem
==========================

.. currentmodule:: spacepy.irbempy

.. autofunction:: prep_irbem