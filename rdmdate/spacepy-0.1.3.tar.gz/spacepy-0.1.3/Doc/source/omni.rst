

###################################################
omni - module to read and process NASA OMNIWEB data
###################################################

.. automodule:: spacepy.omni

.. currentmodule:: spacepy.omni

.. autosummary::
    :toctree: autosummary

    get_omni
