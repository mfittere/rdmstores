spacepy.empiricals.getVampolaOrder
==================================

.. currentmodule:: spacepy.empiricals

.. autofunction:: getVampolaOrder