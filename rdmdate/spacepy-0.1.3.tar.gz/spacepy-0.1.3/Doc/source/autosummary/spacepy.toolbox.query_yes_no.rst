spacepy.toolbox.query_yes_no
============================

.. currentmodule:: spacepy.toolbox

.. autofunction:: query_yes_no