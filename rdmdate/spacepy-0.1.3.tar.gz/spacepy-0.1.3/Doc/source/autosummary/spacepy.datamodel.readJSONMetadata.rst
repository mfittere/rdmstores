spacepy.datamodel.readJSONMetadata
==================================

.. currentmodule:: spacepy.datamodel

.. autofunction:: readJSONMetadata