spacepy.radbelt.get_modelop_L
=============================

.. currentmodule:: spacepy.radbelt

.. autofunction:: get_modelop_L