spacepy.datamodel.SpaceData
===========================

.. currentmodule:: spacepy.datamodel

.. autoclass:: SpaceData