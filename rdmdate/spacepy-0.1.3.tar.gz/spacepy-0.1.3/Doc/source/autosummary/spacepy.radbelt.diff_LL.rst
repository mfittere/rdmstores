spacepy.radbelt.diff_LL
=======================

.. currentmodule:: spacepy.radbelt

.. autofunction:: diff_LL