spacepy.toolbox.applySmartTimeTicks
===================================

.. currentmodule:: spacepy.toolbox

.. autofunction:: applySmartTimeTicks