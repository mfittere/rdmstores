spacepy.datamodel.readJSONheadedASCII
=====================================

.. currentmodule:: spacepy.datamodel

.. autofunction:: readJSONheadedASCII