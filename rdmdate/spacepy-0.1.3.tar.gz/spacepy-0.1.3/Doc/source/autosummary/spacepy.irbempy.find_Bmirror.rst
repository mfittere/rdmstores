spacepy.irbempy.find_Bmirror
============================

.. currentmodule:: spacepy.irbempy

.. autofunction:: find_Bmirror