spacepy.time.randomDate
=======================

.. currentmodule:: spacepy.time

.. autofunction:: randomDate