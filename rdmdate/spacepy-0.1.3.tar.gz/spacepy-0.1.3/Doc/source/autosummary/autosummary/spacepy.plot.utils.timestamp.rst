spacepy.plot.utils.timestamp
============================

.. currentmodule:: spacepy.plot.utils

.. autofunction:: timestamp