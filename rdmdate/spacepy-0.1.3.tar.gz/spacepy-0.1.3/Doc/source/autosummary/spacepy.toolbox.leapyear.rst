spacepy.toolbox.leapyear
========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: leapyear