spacepy.toolbox.logspace
========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: logspace