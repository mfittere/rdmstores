spacepy.pycdf.CDFError
======================

.. currentmodule:: spacepy.pycdf

.. autoclass:: CDFError