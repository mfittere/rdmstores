spacepy.pycdf.EpochError
========================

.. currentmodule:: spacepy.pycdf

.. autoclass:: EpochError