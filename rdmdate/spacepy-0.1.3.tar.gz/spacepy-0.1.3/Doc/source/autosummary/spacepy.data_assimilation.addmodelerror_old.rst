spacepy.data_assimilation.addmodelerror_old
===========================================

.. currentmodule:: spacepy.data_assimilation

.. autofunction:: addmodelerror_old