spacepy.plot.spectrogram.spectrogram
====================================

.. currentmodule:: spacepy.plot.spectrogram

.. autoclass:: spectrogram