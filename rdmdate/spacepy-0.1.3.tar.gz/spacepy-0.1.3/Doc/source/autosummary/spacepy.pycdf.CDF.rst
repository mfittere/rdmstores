spacepy.pycdf.CDF
=================

.. currentmodule:: spacepy.pycdf

.. autoclass:: CDF