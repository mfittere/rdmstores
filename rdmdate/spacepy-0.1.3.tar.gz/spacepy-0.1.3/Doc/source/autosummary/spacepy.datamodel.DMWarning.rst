spacepy.datamodel.DMWarning
===========================

.. currentmodule:: spacepy.datamodel

.. autoclass:: DMWarning