spacepy.datamodel.flatten
=========================

.. currentmodule:: spacepy.datamodel

.. autofunction:: flatten