spacepy.data_assimilation.getobs4window
=======================================

.. currentmodule:: spacepy.data_assimilation

.. autofunction:: getobs4window