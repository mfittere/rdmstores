spacepy.toolbox.dictree
=======================

.. currentmodule:: spacepy.toolbox

.. autofunction:: dictree