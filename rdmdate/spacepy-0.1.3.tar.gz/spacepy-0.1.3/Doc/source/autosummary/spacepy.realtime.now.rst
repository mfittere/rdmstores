spacepy.realtime.now
====================

.. currentmodule:: spacepy.realtime

.. autofunction:: now