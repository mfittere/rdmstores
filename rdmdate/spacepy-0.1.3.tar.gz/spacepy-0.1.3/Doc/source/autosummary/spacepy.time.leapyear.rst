spacepy.time.leapyear
=====================

.. currentmodule:: spacepy.time

.. autofunction:: leapyear