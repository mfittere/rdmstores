spacepy.toolbox.getNamedPath
============================

.. currentmodule:: spacepy.toolbox

.. autofunction:: getNamedPath