spacepy.omni.get_omni
=====================

.. currentmodule:: spacepy.omni

.. autofunction:: get_omni