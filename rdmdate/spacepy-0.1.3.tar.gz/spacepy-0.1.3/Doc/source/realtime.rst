

#######################################################
realtime - Set of tools for realtime and forcasted data
#######################################################

.. automodule:: spacepy.realtime

.. currentmodule:: spacepy.realtime

.. autosummary::
    :toctree: autosummary

    nextForecast
    now
    forecast

