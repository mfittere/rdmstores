spacepy.poppy.value_percentile
==============================

.. currentmodule:: spacepy.poppy

.. autofunction:: value_percentile