spacepy.plot.utils.printfig
===========================

.. currentmodule:: spacepy.plot.utils

.. autofunction:: printfig