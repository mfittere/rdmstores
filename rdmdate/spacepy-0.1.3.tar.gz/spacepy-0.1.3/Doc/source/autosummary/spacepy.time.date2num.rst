spacepy.time.date2num
=====================

.. currentmodule:: spacepy.time

.. autofunction:: date2num