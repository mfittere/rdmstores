spacepy.datamodel.dmarray
=========================

.. currentmodule:: spacepy.datamodel

.. autoclass:: dmarray