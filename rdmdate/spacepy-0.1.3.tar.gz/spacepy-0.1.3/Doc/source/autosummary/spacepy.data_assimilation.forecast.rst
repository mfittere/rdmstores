spacepy.data_assimilation.forecast
==================================

.. currentmodule:: spacepy.data_assimilation

.. autofunction:: forecast