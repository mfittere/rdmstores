spacepy.toolbox.feq
===================

.. currentmodule:: spacepy.toolbox

.. autofunction:: feq