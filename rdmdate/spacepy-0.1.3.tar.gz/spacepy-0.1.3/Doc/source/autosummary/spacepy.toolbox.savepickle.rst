spacepy.toolbox.savepickle
==========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: savepickle