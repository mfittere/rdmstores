spacepy.toolbox.isview
======================

.. currentmodule:: spacepy.toolbox

.. autofunction:: isview