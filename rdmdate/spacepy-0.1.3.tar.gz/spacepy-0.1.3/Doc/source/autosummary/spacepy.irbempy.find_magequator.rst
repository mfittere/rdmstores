spacepy.irbempy.find_magequator
===============================

.. currentmodule:: spacepy.irbempy

.. autofunction:: find_magequator