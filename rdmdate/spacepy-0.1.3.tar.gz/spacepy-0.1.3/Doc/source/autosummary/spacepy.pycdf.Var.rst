spacepy.pycdf.Var
=================

.. currentmodule:: spacepy.pycdf

.. autoclass:: Var