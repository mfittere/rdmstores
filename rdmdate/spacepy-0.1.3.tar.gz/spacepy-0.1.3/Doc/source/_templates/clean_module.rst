{{ fullname }}
{{ underline }}

.. currentmodule:: {{ module }}

.. automodule:: {{ fullname }}
