spacepy.radbelt.RBmodel
=======================

.. currentmodule:: spacepy.radbelt

.. autoclass:: RBmodel