spacepy.plot.spectrogram
========================

.. currentmodule:: spacepy.plot

.. automodule:: spacepy.plot.spectrogram