

##################################
PoPPy - Point Processes in Python
##################################

.. automodule:: spacepy.poppy

.. currentmodule:: spacepy.poppy

.. rubric:: Classes

.. autosummary::
    :template: clean_class.rst
    :toctree: autosummary

    PPro

.. rubric:: Functions

.. autosummary::
    :toctree: autosummary

    plot_two_ppro
    boots_ci
    value_percentile
