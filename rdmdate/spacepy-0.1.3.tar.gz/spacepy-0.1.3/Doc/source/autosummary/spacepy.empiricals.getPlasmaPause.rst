spacepy.empiricals.getPlasmaPause
=================================

.. currentmodule:: spacepy.empiricals

.. autofunction:: getPlasmaPause