spacepy.data_assimilation.output
================================

.. currentmodule:: spacepy.data_assimilation

.. autofunction:: output