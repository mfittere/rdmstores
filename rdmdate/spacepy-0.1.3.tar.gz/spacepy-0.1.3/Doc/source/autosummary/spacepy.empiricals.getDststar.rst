spacepy.empiricals.getDststar
=============================

.. currentmodule:: spacepy.empiricals

.. autofunction:: getDststar