spacepy.pycdf.gAttrList
=======================

.. currentmodule:: spacepy.pycdf

.. autoclass:: gAttrList