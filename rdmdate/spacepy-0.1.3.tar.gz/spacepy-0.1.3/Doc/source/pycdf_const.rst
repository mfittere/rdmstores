

############################################
pycdf.const - Constants from the CDF library
############################################

.. automodule:: spacepy.pycdf.const