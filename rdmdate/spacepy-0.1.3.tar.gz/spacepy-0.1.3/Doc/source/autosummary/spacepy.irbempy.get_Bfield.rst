spacepy.irbempy.get_Bfield
==========================

.. currentmodule:: spacepy.irbempy

.. autofunction:: get_Bfield