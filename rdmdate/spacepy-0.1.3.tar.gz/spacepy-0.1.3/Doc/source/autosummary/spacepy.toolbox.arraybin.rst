spacepy.toolbox.arraybin
========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: arraybin