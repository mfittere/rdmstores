spacepy.time.tickrange
======================

.. currentmodule:: spacepy.time

.. autofunction:: tickrange