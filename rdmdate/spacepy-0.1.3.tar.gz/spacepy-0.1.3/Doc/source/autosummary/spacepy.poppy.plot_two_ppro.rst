spacepy.poppy.plot_two_ppro
===========================

.. currentmodule:: spacepy.poppy

.. autofunction:: plot_two_ppro