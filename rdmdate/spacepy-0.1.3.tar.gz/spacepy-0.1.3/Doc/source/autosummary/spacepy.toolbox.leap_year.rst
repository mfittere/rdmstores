spacepy.toolbox.leap_year
=========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: leap_year