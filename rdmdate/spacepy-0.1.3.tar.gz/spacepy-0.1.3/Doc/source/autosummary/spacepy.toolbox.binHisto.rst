spacepy.toolbox.binHisto
========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: binHisto