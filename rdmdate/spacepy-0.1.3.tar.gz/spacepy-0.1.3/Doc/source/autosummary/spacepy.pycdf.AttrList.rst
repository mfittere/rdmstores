spacepy.pycdf.AttrList
======================

.. currentmodule:: spacepy.pycdf

.. autoclass:: AttrList