spacepy.toolbox.geomspace
=========================

.. currentmodule:: spacepy.toolbox

.. autofunction:: geomspace