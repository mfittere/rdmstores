spacepy.irbempy.get_sysaxes
===========================

.. currentmodule:: spacepy.irbempy

.. autofunction:: get_sysaxes