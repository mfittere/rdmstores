spacepy.pycdf.Library
=====================

.. currentmodule:: spacepy.pycdf

.. autoclass:: Library